//
//  Extensions.swift
//  API
//
//  Created by macintosh on 25/03/22.
//

import Foundation
import UIKit
import Alamofire

//MARK:- API Functions

extension UIViewController {
    
    func callAPI(apiURL:String,
             method:HTTPMethod ,
             _ isLoader : Bool = true ,
             _ isHeader : Bool = false ,
//                 _ customHeader : HTTPHeader = [String:Any],
             param:[String:Any],
             _ encoding: ParameterEncoding = JSONEncoding.default ,
             completion: @escaping ([String:Any]?,Int) -> Void)

    {
        guard let url = URL(string: apiURL) else {
            completion(nil , 0)
            return
        }
        
        AF.request(url,
                   method: method,
                   parameters: param.count == 0 ? nil : param,
                   encoding: encoding,
//                       encoding: JSONEncoding.default,
//                       encoding: URLEncoding.default,
//                   headers: headers,
                   interceptor: nil,
                   requestModifier: nil)
            .responseJSON(completionHandler: { (response) in
                print(response)
                
                switch response.result
                {
                case .success(let json):
                    _ = json as? [String: Any]
                    
                case .failure(let error):
                    print(error)
                }
            }
        )}
}

//MARK:- Staus Codes

let HTTP_OK = 200
let HTTP_UNAUTHORIZED = 401
let HTTP_UNVERIFIED = 403
let HTTP_INTERNAL_SERVER_ERROR = 500

enum StatusCode:Int
{
    case HTTP_Ok                 = 200
    case NotFound                = 404
    case Unauthorized            = 401
    case BadRequest              = 400
    case HTTP_Created            = 201
    case NotContent              = 204
    case NotVerify               = 206

}

//MARK:- API URL

//let BASE_API_URL = "https://api.kangoexpress.com"

let BASE_API_URL = "http://103.138.233.94:12561"
//let BASE_IMAGE_URL = ""
//let BASE_PAGES_URL = "http://3.144.0.70:8083"

struct UserWebUrl
{
    
    static var Login :String
    {
        return "\(BASE_API_URL)/api/WarehousesCollection/GetAll"
    }
}
