

import Foundation
import ObjectMapper

struct WarehouseAddressData : Mappable {
	var warehouseId : Int?
	var title : String?
	var warehouseCode : String?
	var warehouseInitial : String?
	var overview : String?
	var address : String?
	var hoursOperation : String?
	var contactNo : String?
	var contactPerson : String?
	var shipperName : String?
	var shipperAddress : String?
	var zipcode : String?
	var address1 : String?
	var address2 : String?
	var division : String?
	var divisionCode : String?
	var shippingPersonName : String?
	var shippingPersonContact : String?
	var shippingPhoneExtension : String?
	var shippingFaxNumber : String?
	var shippingTelex : String?
	var shippingEmail : String?
	var countryId : Int?
	var featureImageUrl : String?
	var createdDate : String?
	var name : String?
	var flagUrl : String?
	var country : [Any]?
	var isActive : Bool?

    var city : String?
	init?(map: Map) {

	}

	mutating func mapping(map: Map) {

		warehouseId <- map["warehouseId"]
		title <- map["title"]
		warehouseCode <- map["warehouseCode"]
		warehouseInitial <- map["warehouseInitial"]
		overview <- map["overview"]
		address <- map["address"]
		hoursOperation <- map["hoursOperation"]
		contactNo <- map["contactNo"]
		contactPerson <- map["contactPerson"]
		shipperName <- map["shipperName"]
		shipperAddress <- map["shipperAddress"]
		zipcode <- map["zipcode"]
		address1 <- map["address1"]
		address2 <- map["address2"]
		division <- map["division"]
		divisionCode <- map["divisionCode"]
		shippingPersonName <- map["shippingPersonName"]
		shippingPersonContact <- map["shippingPersonContact"]
		shippingPhoneExtension <- map["shippingPhoneExtension"]
		shippingFaxNumber <- map["shippingFaxNumber"]
		shippingTelex <- map["shippingTelex"]
		shippingEmail <- map["shippingEmail"]
		countryId <- map["countryId"]
		featureImageUrl <- map["featureImageUrl"]
		createdDate <- map["createdDate"]
		name <- map["name"]
		flagUrl <- map["flagUrl"]
		country <- map["country"]
		isActive <- map["isActive"]
        city <- map["city"]
	}

}
