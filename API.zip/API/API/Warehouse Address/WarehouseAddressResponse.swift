

import Foundation
import ObjectMapper

struct WarehouseAddressResponse : Mappable {
	var statusCode : Int?
	var message : String?
	var result : [WarehouseAddressData]?

	init?(map: Map) {

	}

	mutating func mapping(map: Map) {

		statusCode <- map["statusCode"]
		message <- map["message"]
		result <- map["result"]
	}

}
