/* 
Copyright (c) 2022 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Result : Codable {
	let warehouseId : Int?
	let title : String?
	let warehouseCode : String?
	let warehouseInitial : String?
	let overview : String?
	let address : String?
	let hoursOperation : String?
	let contactNo : String?
	let contactPerson : String?
	let shipperName : String?
	let shipperAddress : String?
	let zipcode : String?
	let address1 : String?
	let address2 : String?
	let division : String?
	let divisionCode : String?
	let shippingPersonName : String?
	let shippingPersonContact : String?
	let shippingPhoneExtension : String?
	let shippingFaxNumber : String?
	let shippingTelex : String?
	let shippingEmail : String?
	let countryId : Int?
	let featureImageUrl : String?
	let createdDate : String?
	let name : String?
	let flagUrl : String?
	let country : Country?
	let isActive : Bool?
	let city : String?

	enum CodingKeys: String, CodingKey {

		case warehouseId = "warehouseId"
		case title = "title"
		case warehouseCode = "warehouseCode"
		case warehouseInitial = "warehouseInitial"
		case overview = "overview"
		case address = "address"
		case hoursOperation = "hoursOperation"
		case contactNo = "contactNo"
		case contactPerson = "contactPerson"
		case shipperName = "shipperName"
		case shipperAddress = "shipperAddress"
		case zipcode = "zipcode"
		case address1 = "address1"
		case address2 = "address2"
		case division = "division"
		case divisionCode = "divisionCode"
		case shippingPersonName = "shippingPersonName"
		case shippingPersonContact = "shippingPersonContact"
		case shippingPhoneExtension = "shippingPhoneExtension"
		case shippingFaxNumber = "shippingFaxNumber"
		case shippingTelex = "shippingTelex"
		case shippingEmail = "shippingEmail"
		case countryId = "countryId"
		case featureImageUrl = "featureImageUrl"
		case createdDate = "createdDate"
		case name = "name"
		case flagUrl = "flagUrl"
		case country = "country"
		case isActive = "isActive"
		case city = "city"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		warehouseId = try values.decodeIfPresent(Int.self, forKey: .warehouseId)
		title = try values.decodeIfPresent(String.self, forKey: .title)
		warehouseCode = try values.decodeIfPresent(String.self, forKey: .warehouseCode)
		warehouseInitial = try values.decodeIfPresent(String.self, forKey: .warehouseInitial)
		overview = try values.decodeIfPresent(String.self, forKey: .overview)
		address = try values.decodeIfPresent(String.self, forKey: .address)
		hoursOperation = try values.decodeIfPresent(String.self, forKey: .hoursOperation)
		contactNo = try values.decodeIfPresent(String.self, forKey: .contactNo)
		contactPerson = try values.decodeIfPresent(String.self, forKey: .contactPerson)
		shipperName = try values.decodeIfPresent(String.self, forKey: .shipperName)
		shipperAddress = try values.decodeIfPresent(String.self, forKey: .shipperAddress)
		zipcode = try values.decodeIfPresent(String.self, forKey: .zipcode)
		address1 = try values.decodeIfPresent(String.self, forKey: .address1)
		address2 = try values.decodeIfPresent(String.self, forKey: .address2)
		division = try values.decodeIfPresent(String.self, forKey: .division)
		divisionCode = try values.decodeIfPresent(String.self, forKey: .divisionCode)
		shippingPersonName = try values.decodeIfPresent(String.self, forKey: .shippingPersonName)
		shippingPersonContact = try values.decodeIfPresent(String.self, forKey: .shippingPersonContact)
		shippingPhoneExtension = try values.decodeIfPresent(String.self, forKey: .shippingPhoneExtension)
		shippingFaxNumber = try values.decodeIfPresent(String.self, forKey: .shippingFaxNumber)
		shippingTelex = try values.decodeIfPresent(String.self, forKey: .shippingTelex)
		shippingEmail = try values.decodeIfPresent(String.self, forKey: .shippingEmail)
		countryId = try values.decodeIfPresent(Int.self, forKey: .countryId)
		featureImageUrl = try values.decodeIfPresent(String.self, forKey: .featureImageUrl)
		createdDate = try values.decodeIfPresent(String.self, forKey: .createdDate)
		name = try values.decodeIfPresent(String.self, forKey: .name)
		flagUrl = try values.decodeIfPresent(String.self, forKey: .flagUrl)
		country = try values.decodeIfPresent(Country.self, forKey: .country)
		isActive = try values.decodeIfPresent(Bool.self, forKey: .isActive)
		city = try values.decodeIfPresent(String.self, forKey: .city)
	}

}