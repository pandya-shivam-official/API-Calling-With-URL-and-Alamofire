/* 
Copyright (c) 2022 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Country : Codable {
	let franchises : [String]?
	let countryId : Int?
	let countryName : String?
	let countryCode : String?
	let title : String?
	let phoneCode : Int?
	let welcomeTitle : String?
	let specialNotes : String?
	let generalOverViewStmt : String?
	let transitTimeDesc : String?
	let customsDutyInfo : String?
	let services : String?
	let flagUrl : String?
	let isDirectServiceAvailable : Bool?
	let isConsoServiceAvailable : Bool?
	let countryRates : [String]?
	let countryWarehouseMapping : [String]?

	enum CodingKeys: String, CodingKey {

		case franchises = "franchises"
		case countryId = "countryId"
		case countryName = "countryName"
		case countryCode = "countryCode"
		case title = "title"
		case phoneCode = "phoneCode"
		case welcomeTitle = "welcomeTitle"
		case specialNotes = "specialNotes"
		case generalOverViewStmt = "generalOverViewStmt"
		case transitTimeDesc = "transitTimeDesc"
		case customsDutyInfo = "customsDutyInfo"
		case services = "services"
		case flagUrl = "flagUrl"
		case isDirectServiceAvailable = "isDirectServiceAvailable"
		case isConsoServiceAvailable = "isConsoServiceAvailable"
		case countryRates = "countryRates"
		case countryWarehouseMapping = "countryWarehouseMapping"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		franchises = try values.decodeIfPresent([String].self, forKey: .franchises)
		countryId = try values.decodeIfPresent(Int.self, forKey: .countryId)
		countryName = try values.decodeIfPresent(String.self, forKey: .countryName)
		countryCode = try values.decodeIfPresent(String.self, forKey: .countryCode)
		title = try values.decodeIfPresent(String.self, forKey: .title)
		phoneCode = try values.decodeIfPresent(Int.self, forKey: .phoneCode)
		welcomeTitle = try values.decodeIfPresent(String.self, forKey: .welcomeTitle)
		specialNotes = try values.decodeIfPresent(String.self, forKey: .specialNotes)
		generalOverViewStmt = try values.decodeIfPresent(String.self, forKey: .generalOverViewStmt)
		transitTimeDesc = try values.decodeIfPresent(String.self, forKey: .transitTimeDesc)
		customsDutyInfo = try values.decodeIfPresent(String.self, forKey: .customsDutyInfo)
		services = try values.decodeIfPresent(String.self, forKey: .services)
		flagUrl = try values.decodeIfPresent(String.self, forKey: .flagUrl)
		isDirectServiceAvailable = try values.decodeIfPresent(Bool.self, forKey: .isDirectServiceAvailable)
		isConsoServiceAvailable = try values.decodeIfPresent(Bool.self, forKey: .isConsoServiceAvailable)
		countryRates = try values.decodeIfPresent([String].self, forKey: .countryRates)
		countryWarehouseMapping = try values.decodeIfPresent([String].self, forKey: .countryWarehouseMapping)
	}

}