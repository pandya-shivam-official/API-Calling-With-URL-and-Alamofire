//
//  ViewController.swift
//  API
//
//  Created by macintosh on 25/03/22.
//

import UIKit
import Alamofire
import ObjectMapper


class ViewController: UIViewController {
    
    var WareHouse = [WarehouseAddressData]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        API()

    }
    
    func API() {
        
//        let strurl = UserWebUrl.Login // "http://3.144.0.70:8083/api/WarehousesCollection/GetAll"
//        let urlString =  strurl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
//
//    callAPI(apiURL: urlString, method: .get , true , true , param: [:], completion: { [weak self] (response,statuscode)  in
//
//        guard let _ = self else {return}
//
//        if(statuscode == HTTP_UNAUTHORIZED)
//        {
//
//        }
//        else if response != nil{
//            if statuscode == HTTP_OK {
//
//                if let countryRes = response
//                {
//                    let country = WarehouseAddressResponse(JSON:countryRes)
//                    self?.WareHouse = country?.result ?? []
//                    print(country)
//                }
//
//            }
//        }
//    })
//         AF
//                let url = "http://3.144.0.70:8083/api/WarehousesCollection/GetAll"
        
                let url = "https://dummy.restapiexample.com/api/v1/employees"
        
        AF.request(url, method: .get, encoding: JSONEncoding.default)
            .responseJSON { response in
                
                

                switch response.result {

                case .success(let json):
                    print(json)
//                    DispatchQueue.main.async {
//
//                         handle your code
//                        let country = WarehouseAddressResponse(JSON:json as? [String : Any] ?? [:])
//                        self.WareHouse = country?.result ?? []
//                        print(country)
//
//                    }
                case .failure(let error):
                    print(error)
                }
            }
        
        // URLSession
        
//        URLSession.shared.dataTask(with: URL(string: strurl)!) { data, response, error in
//            if error == nil{
//                if let data = data {
//                    do{
//                        let userResponse = try JSONDecoder().decode(Result.self, from: data)
//                        print(userResponse)
//
//                    }catch{
//                        print(error.localizedDescription)
//                    }
//                }
//            }else{
//                print(error?.localizedDescription)
//            }
//        }.resume()

//
        // AF
//        AF.request(urlString, method: .get, encoding: JSONEncoding.default)
//            .responseJSON { response in
//
//            switch response.result {
//
//            case .success(let Json):
////                print(Json)
//                DispatchQueue.main.async {
//                    let country = WarehouseAddressResponse(JSON: Json as? [String:Any] ?? [:] )
//                    self.WareHouse = country?.result ?? []
//                    print(country!)
//                }
//
//            case .failure(let error):
//                print(error)
//            }
//        }
        
        // AF
        
//        AF.request(urlString, method: .get)
//          .responseJSON { response in
//            if let value = response.value {
//                print(value)
//            }else{
//                print("error")
//            }
//        }
        
        // Response Handling
        
//        AF.request(urlString,method: .get)
//                 .responseJSON { response in
//                     print(response.request)  // original URL request // your url with path
//                     print(response.response) // URL response
//                     print(response.data)     // server data
//                     print(response.result)   // result of response serialization

    // Response Serialization
        
        //        Built-in Response Methods
        //
        //        response()
        //        responseData()
        //        responseString(encoding: NSStringEncoding)
        //        responseJSON(options: NSJSONReadingOptions)
        //        responsePropertyList(options: NSPropertyListReadOptions)
        
            // Response Handler
        
//        AF.request(urlString, method: .get, parameters: ["foo": "bar"])
//                 .response { request, response, data, error in
//                     print(request)
//                     print(response)
//                     print(data)
//                     print(error)
//                  }
        
            // Response Data Handler
        
//        AF.request( urlString, method:.get, parameters: ["foo": "bar"])
//                 .responseData { response in
//                     print(response.request)
//                     print(response.response)
//                     print(response.result)
//                  }
            
            // Response String Handler
//        AF.request(urlString, method:.get)
//                 .responseString { response in
//                     print("Success: \(response.result.isSuccess)")
//                     print("Response String: \(response.result.value)")
                 }
    }

