//
//  File.swift
//  API
//
//  Created by macintosh on 29/03/22.
//

import Foundation

//in API calling wee need
//
//( - url
//  - method
//  - Parameters
//  - encoding
//  - header)
//           .responseJson {(Response:DataResponse<any>)-> void in
//  // switch or if code hear
//    }

//_ url: URLConvertible,
//    method: HTTPMethod = .get,
//    parameters: Parameters? = nil,
//    encoding: ParameterEncoding = URLEncoding.default,
//    headers: HTTPHeaders? = nil)
//    -> DataRequest



//Usage : (https://cocoapods.org/pods/Alamofire-Result)

// Making a Request

//import Alamofire_Result
//
//Alamofire.request(.GET, "https://httpbin.org/get")

//Response Handling
//Alamofire_Result.request(.GET, "https://httpbin.org/get", parameters: ["foo": "bar"])
//         .responseJSON { response in
//             print(response.request)  // original URL request
//             print(response.response) // URL response
//             print(response.data)     // server data
//             print(response.result)   // result of response serialization
//
//             if let JSON = response.result.value {
//                 print("JSON: \(JSON)")
//             }
//         }
